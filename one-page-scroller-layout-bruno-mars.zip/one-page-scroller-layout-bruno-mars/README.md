# One-page scroller layout/ Bruno mars

A Pen created on CodePen.

Original URL: [https://codepen.io/Jaqueline-Sica/pen/Kwzdjje](https://codepen.io/Jaqueline-Sica/pen/Kwzdjje).

